#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np

roll_list = ['001', '002', '004', '006', '008', '010', '012', '014', 'graphene']
for k in range(0, len(roll_list)):
    with open(roll_list[k] + '.xyz', 'r') as fl:
        line = fl.readlines()
        all_coord = []
        l0 = line[0]
        l1 = line[1]
        Lx = float(line[1].strip('\n').split()[0].split('"')[1])
        Ly = float(line[1].strip('\n').split()[4])
        for i in range(2, len(line)):
            coord = []
            coord.append(line[i].strip('\n').split()[1])
            coord.append(line[i].strip('\n').split()[2])
            coord.append(line[i].strip('\n').split()[3])
            all_coord.append(coord)
    coord_list = np.array(all_coord, dtype=float)
    natom = int(l0)
    new_coord = np.zeros((natom, 3), dtype=float)
    box = round(Ly / np.pi + 20, 4)
    if box % 2 == 0:
        origin_box = -round(box / 2, 4)
    else:
        origin_box = -round(box / 2, 5)
    for i in range(0, len(coord_list)):
        new_coord[i][0] = Ly / 2 / np.pi * np.cos(2 * np.pi * coord_list[i][1] / Ly)
        new_coord[i][1] = Ly / 2 / np.pi * np.sin(2 * np.pi * coord_list[i][1] / Ly)
        new_coord[i][2] = coord_list[i][0]
    with open(roll_list[k] + '_roll.xyz', 'w') as fl:
        fl.writelines(l0)
        fl.writelines('Lattice="' + str(Lx) + ' 0.0 0.0 0.0 ' + str(box) + ' 0.0 0.0 0.0 ' +
                    str(box) + '" Properties=species:S:1:pos:R:3\n')
        for i in range(0, len(new_coord)):
            fl.writelines('C ' + str(new_coord[i][2]) + ' ')
            fl.writelines(str(new_coord[i][1]) + ' ')
            fl.writelines(str(new_coord[i][0]) + '\n')
