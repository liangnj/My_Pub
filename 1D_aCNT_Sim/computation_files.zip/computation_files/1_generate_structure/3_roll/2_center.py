from pylab import *
from ase.io import read, write
from ase.io.extxyz import write_extxyz
import numpy as np
from gpyumd.atoms import GpumdAtoms
from gpyumd.load import load_shc, load_compute


atoms = read('008_roll.xyz')
structure = GpumdAtoms(atoms)
lx, ly, lz = structure.cell.lengths()
structure.center()
structure.pbc= [True, False, False]
write_extxyz("model_008.xyz", structure, columns = ['symbols', 'positions'])

