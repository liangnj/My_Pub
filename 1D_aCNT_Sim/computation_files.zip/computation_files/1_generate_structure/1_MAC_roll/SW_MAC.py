#!/usr/bin/env python
# -*- coding: utf-8 -*-
#

import numpy as np
from scipy.spatial import cKDTree


for step in range(0, 1100):
    info = []
    all_coords = []
    all_bonds = []
    with open("step-" + str(step) + ".data", 'r') as fl:
        line = fl.readlines()
        for i in range(0, 15):
            info.append(line[i])
        Natoms = int(line[2].strip('\n').split()[0])
        lattice_a = float(line[5].strip('\n').split()[1])
        lattice_b = float(line[6].strip('\n').split()[1])
        for i in range(15, 15 + int(Natoms)):
            coord = []
            coord.append(line[i].strip('\n').split()[2])
            coord.append(line[i].strip('\n').split()[3])
            all_coords.append(coord)
    positions = np.array(all_coords, dtype=float)
    positions_old = positions
    kd = cKDTree(positions)
    pairs = np.array(list(kd.query_pairs(1.85)))
    Nrandom = np.random.randint(0, len(pairs))
    position1 = positions[pairs[Nrandom][0]]
    position2 = positions[pairs[Nrandom][1]]
    center = (position1 + position2)/2
    position1 = position1 - center
    position2 = position2 - center
    position1 = [position1[1], -position1[0]] + center
    if position1[0] > lattice_a:
        position1[0] = position1[0] - lattice_a
    if position1[0] < 0:
        position1[0] = position1[0] + lattice_a
    if position1[1] > lattice_b:
        position1[1] = position1[1] - lattice_b
    if position1[1] < 0:
        position1[1] = position1[1] + lattice_b
    position2 = [position2[1], -position2[0]] + center
    if position2[0] > lattice_a:
        position2[0] = position2[0] - lattice_a
    if position2[0] < 0:
        position2[0] = position2[0] + lattice_a
    if position2[1] > lattice_b:
        position2[1] = position2[1] - lattice_b
    if position2[1] < 0:
        position2[1] = position2[1] + lattice_b
    positions[pairs[Nrandom][0]] = position1
    positions[pairs[Nrandom][1]] = position2
    with open("step-" + str(step + 1) + ".data", 'w') as fl:
        for i in range(0, len(info)):
            fl.writelines(info[i])
        for i in range(0, Natoms):
            fl.writelines(str(i + 1) + " ")
            fl.writelines("1 ")
            fl.writelines(str(positions[i][0]) + " " + str(positions[i][1]))
            fl.writelines(" 10.0\n")
