from pylab import *
from ase.build import graphene_nanoribbon
from gpyumd.atoms import GpumdAtoms
from ase.io import write
from gpyumd.load import load_shc, load_thermo, load_kappa
from gpyumd.math import running_ave
from gpyumd.calc import calc_spectral_kappa


aw = 2
fs = 16
font = {'size'   : fs}
matplotlib.rc('font', **font)
matplotlib.rc('axes' , linewidth=aw)

def set_fig_properties(ax_list):
    tl = 8
    tw = 2
    tlm = 4
    
    for ax in ax_list:
        ax.tick_params(which='major', length=tl, width=tw)
        ax.tick_params(which='minor', length=tlm, width=tw)
        ax.tick_params(which='both', axis='both', direction='in', right=True, top=True)

shc = load_shc(num_corr_points=500, num_omega=1000)['run0']
# print(shc.keys())
thermo = load_thermo()
Lx = thermo['Lx'][-1]
V = Lx * 24.6 * 3.4
kappa = load_kappa()
T = 300
Fe = 5e-5
calc_spectral_kappa(shc, driving_force=Fe, temperature=T, volume=V)
print(shc.keys())
shc['kw'] = shc['kwi'] + shc['kwo']
shc['K'] = shc['Ki'] + shc['Ko']
# Gc = np.load('Gc.npy')
# print(shc.keys())

# lambda_i = shc['kw']/Gc
# length = np.logspace(1,6,100)
# k_L = np.zeros_like(length)
# for i, el in enumerate(length):
#     k_L[i] = np.trapz(shc['kw']/(1+lambda_i/el), shc['nu'])

figure(figsize=(12,10))
subplot(2,2,1)
set_fig_properties([gca()])
plot(shc['t'], shc['K']/Lx, linewidth=3)
# xlim([-0.5, 0.5])
# gca().set_xticks([-0.5, 0, 0.5])
# ylim([-1, 5])
# gca().set_yticks(range(-1,6,1))
ylabel('K (eV/ps)')
xlabel('Correlation time (ps)')
title('(a)')

subplot(2,2,2)
set_fig_properties([gca()])
plot(shc['nu'], shc['kw'],linewidth=3)
# xlim([0, 50])
# gca().set_xticks(range(0,51,10))
# ylim([0, 200])
# gca().set_yticks(range(0,201,50))
ylabel(r'$\kappa$($\omega$) (W/m/K/THz)')
xlabel(r'$\nu$ (THz)')
title('(b)')


tight_layout()
savefig('shc.png')
show()
close()

