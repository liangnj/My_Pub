
import numpy as np
import matplotlib.pyplot as plt
import opt_einsum as oe
import sys
sys.path.append('./hydro_glassesL/')
from time import time
from ase.io import read,write
from ase import units
from hydro_glassesL import lanczos,test_lanczos,hydrodynamic
from hydro_glassesL import amorphous_tools as at
import os
import logging
from scipy import sparse
#multiprocessing
from multiprocessing import Pool
from scipy.optimize import curve_fit


atoms = read('replicated_atoms.xyz')
positions = np.array([atoms.get_positions()])
pos = np.transpose(positions, axes = (0, 2, 1))
reciprocal_cell = np.linalg.inv(atoms.cell)
Lx=atoms.cell[0][0]
print(Lx)
nq=352

Q_list = np.array([[i,0,0] for i in range(nq+1)]) #Gamma-M path #caution is needed because this cell is triclinic not the usual cell of graphene
Q_list = np.delete(Q_list, np.argwhere((Q_list == [0, 0, 0]).all(axis = 1)), axis = 0)
N=atoms.get_global_number_of_atoms()
print(N)
nmodes=N*3
eigval=np.load('eigval.npy')
eigvec=np.load('eigvec.npy')


# f = np.sqrt(np.abs(eigval))*np.sign(eigval) / 2 / np.pi
# f[:4] = 0
# f[f < 0] = 0
# gamma = np.zeros_like(f)
# spl = np.load(f'aCNT.linewidth.N240.T300K.spline.npy', allow_pickle = True).item()
# gamma[f <= 53.398] = spl(f[f <= 53.398])
# gamma = np.array([gamma])

eta=0.2
Q, omega, S = at.compute_SQomega(Q_list, 
                                 np.array([eigval]), 
                                 np.array([eigvec]), 
                                 positions, 
                                 reciprocal_cell,
                                 cutoff = 300/2/np.pi, # THz
                                 domega = eta, # rad/ps
                                 nomega = 20000,
                                 use_soft = False,#Tinclude the few modes with negative frequency. I don't see any effect
                                 is_anharmonic = False,
                                 vectorize=True)#for debugging set false
qnorm=np.linalg.norm(Q,axis=1)
# print(S.shape)
S_Qw = {'Q': Q, 'omega': omega, 'S': S}
np.save(f'S_Qw_har_direct.eta0.2.no2piL.npy', S_Qw)
np.savetxt('qL.txt', qnorm, fmt = '%.6f', delimiter = '\n')
np.savetxt('freqL.txt', omega/2/np.pi, fmt = '%.6f', delimiter = ' ')
np.savetxt('SqwL.txt', S['L'][:,:,0], fmt = '%.6f', delimiter = ' ')
with open('Sqw_normL.txt', 'w') as fl:
    for iq in range(0, S['L'].shape[0]):
        y=S['L'][iq,:,0]
        x=omega/2/np.pi
        norm=np.trapz(y,x)
        y=y/norm
        for j in range(0, len(y)):
            fl.writelines(str(format(y[j], '.6f')) + ' ')
        fl.writelines('\n')

# is_show=True
# if is_show:
#     fig,ax=plt.subplots()
#     vmax=4e-3
#     p0=ax.pcolormesh(np.linalg.norm(Q,axis=1),omega/2/np.pi,S['L'][:,:,0].T,
#                           shading = 'nearest',
#                           vmin = 0,
#                           vmax = vmax,
#                           cmap = 'inferno')
#     fig.colorbar(p0, ax=ax)
#     plt.legend()
#     plt.title('direct diagonalization eta=0.5')
#     plt.savefig('VDSF.png')
#     plt.show()
#     plt.close()
#     ##VDOS
#     fig,ax=plt.subplots()
#     vdos, bins, patches = ax.hist(f,bins=200)
#     np.savetxt('vdos.txt', np.column_stack((bins[:-1], vdos)), fmt = '%.6f', delimiter = ' ')
#     plt.title('PDOS')
#     plt.savefig('PDOS.png')
#     plt.show()
#     plt.close()

