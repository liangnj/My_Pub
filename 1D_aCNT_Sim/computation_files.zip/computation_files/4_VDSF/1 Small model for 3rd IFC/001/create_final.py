
from ase.build import sort
from ase.io import read,write
atoms=read('aCNT.relaxed.data',format='lammps-data',style='atomic',Z_of_type={1:6})
atoms.set_pbc([True,False,False])
sorted_atoms = sort(atoms, tags=atoms.arrays['id'])
write('replicated_atoms.xyz',sorted_atoms)
print(sorted_atoms)

