from ase.io import read, write
from kaldo.conductivity import Conductivity
from kaldo.forceconstants import ForceConstants
from kaldo.phonons import Phonons
import numpy as np
from scipy.interpolate import interp1d

# Small system (240 atoms)
try:
    forceconstants = ForceConstants.from_folder(folder = '.',
                                                supercell = [1, 1, 1],
                                                format = 'numpy', 
                                                is_acoustic_sum = True)
except:
    forceconstants = ForceConstants.from_folder(folder = '.',
                                                supercell = [1, 1, 1],
                                                format = 'lammps',
                                                is_acoustic_sum = True)

    forceconstants.second.save('second')
    forceconstants.third.save('third', format = 'sparse')

phonons_config = {'is_classic': False,
                  'temperature': 300,
                  'folder': 'N240/ALD',
                  'third_bandwidth': 0.5/4.135,
                  'max_frequency': 60.0, # This is required when using the Tersoff force-field, which features spurious high-frequency modes
                  'broadening_shape': 'gauss',
                  'storage': 'numpy'}

# Define phonons
phonons = Phonons(forceconstants = forceconstants, **phonons_config)
cond = Conductivity(phonons = phonons, method = 'qhgk', storage = 'numpy')

# Compute kappa
kappa = np.diag(cond.conductivity.sum(axis = 0))
with open('kappa.txt', 'w') as fl:
    for i in range(0, len(kappa)):
        fl.writelines(str(format(kappa[i], '.6f')) + '   ')
print(f'QHGK N240: T=300 K, kappa={kappa[0]:.3f} W/m/K')

# Save splined linewidths
f = phonons.frequency.flatten()[3:]
g = phonons.bandwidth.flatten()[3:]
pr = phonons.participation_ratio.flatten()[3:]
ps = phonons.phase_space.flatten()[3:]
with open('mode_sum.txt', 'w') as fl:
    for i in range(0, len(f)):
        fl.writelines(str(format(f[i], '.6f')) + ' ')
        fl.writelines(str(format(g[i], '.6f')) + ' ')
        fl.writelines(str(format(pr[i], '.6f')) + ' ')
        fl.writelines(str(format(ps[i], '.6f')) + '\n')
f[0] = 0
g[0] = 0
spl = interp1d(f, g, kind = 'linear')
np.save(f'N240/aCNT.linewidth.N240.T300K.spline.npy', spl)
print('Done')
