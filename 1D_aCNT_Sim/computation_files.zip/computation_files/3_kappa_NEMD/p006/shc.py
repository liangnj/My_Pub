from pylab import *
from ase.io import read, write
from ase.io.extxyz import write_extxyz
import numpy as np
from gpyumd.atoms import GpumdAtoms
from gpyumd.load import load_shc, load_compute, load_thermo


aw = 2
fs = 16
font = {'size'   : fs}
matplotlib.rc('font', **font)
matplotlib.rc('axes' , linewidth=aw)

atoms = read('model.xyz')
structure = GpumdAtoms(atoms)
lx, ly, lz = structure.cell.lengths()
Lfix = 10
Lbath = 670
nchunk = 7
Lchunk = (lx - 2 * Lfix - 2 * Lbath) / nchunk
# print(Lchunk)

def set_fig_properties(ax_list):
    tl = 8
    tw = 2
    tlm = 4
    
    for ax in ax_list:
        ax.tick_params(which='major', length=tl, width=tw)
        ax.tick_params(which='minor', length=tlm, width=tw)
        ax.tick_params(axis='both', direction='in', right=True, top=True)

compute = load_compute(['temperature'])
T = compute['temperature']
ndata = T.shape[0]
temp_ave = mean(T[int(ndata/2)+1:, 1:], axis=0)
# print(temp_ave)
deltaT = temp_ave[4] - temp_ave[6]  # [K]

shc = load_shc(500, 1000)['run0']
V =  Lchunk * 24.6 * 4.0
Gc = 1.60217663e4*(shc['jwi']+shc['jwo'])/V/deltaT

figure(figsize=(10,5))
subplot(1,2,1)
set_fig_properties([gca()])
plot(shc['t'], (shc['Ki']+shc['Ko'])/Lchunk, linewidth=2)
# xlim([-0.5, 0.5])
# gca().set_xticks([-0.5, 0, 0.5])
# ylim([-4, 10])
# gca().set_yticks(range(-4,11,2))
ylabel('K (eV/ps)')
xlabel('Correlation time (ps)')
title('(a)')

subplot(1,2,2)
set_fig_properties([gca()])
plot(shc['nu'], Gc, linewidth=2)
# xlim([0, 50])
# gca().set_xticks(range(0,51,10))
# ylim([0, 0.35])
# gca().set_yticks(linspace(0,0.35,8))
ylabel(r'$G$($\omega$) (GW/m$^2$/K/THz)')
xlabel(r'$\omega$/2$\pi$ (THz)')
title('(b)')
tight_layout()
savefig('shc.png')
show()
close()

Gc[Gc < 0] = 0
with open('shc.txt', 'w') as fl:
    for i in range(0, len(Gc)):
        fl.writelines('{:.6f}'.format(shc['nu'][i]) + ' ')
        fl.writelines('{:.6f}'.format(Gc[i]) + '\n')

np.save('Gc.npy', Gc)
