from pylab import *
from ase.io import read, write
from ase.io.extxyz import write_extxyz
import numpy as np
from gpyumd.atoms import GpumdAtoms
from gpyumd.load import load_shc, load_compute, load_thermo


atoms = read('model.xyz')
structure = GpumdAtoms(atoms)
lx, ly, lz = structure.cell.lengths()
structure.center()
structure.wrap()
structure.pbc= [False, False, False]

aw = 2
fs = 16
font = {'size'   : fs}
matplotlib.rc('font', **font)
matplotlib.rc('axes' , linewidth=aw)

def set_fig_properties(ax_list):
    tl = 8
    tw = 2
    tlm = 4
    
    for ax in ax_list:
        ax.tick_params(which='major', length=tl, width=tw)
        ax.tick_params(which='minor', length=tlm, width=tw)
        ax.tick_params(axis='both', direction='in', right=True, top=True)


compute = load_compute(['temperature'])
# compute.keys()

T = compute['temperature']
Ein = compute['Ein']
Eout = compute['Eout']
ndata = T.shape[0]
temp_ave = mean(T[int(ndata/2)+1:, 1:], axis=0)

dt = 0.0005  # ps 
Ns = 1000  # Sample interval
t = dt*np.arange(1,ndata+1) * Ns/1000  # ns

ngroup = 9
figure(figsize=(10,5))
subplot(1,2,1)
set_fig_properties([gca()])
group_idx = range(1,ngroup+1)
plot(group_idx, temp_ave,linewidth=3,marker='o',markersize=10)
gca().set_xticks(group_idx)
xlabel('group index')
ylabel('T (K)')
title('(a)')

subplot(1,2,2)
set_fig_properties([gca()])
plot(t, Ein/1000, 'C3', linewidth=3)
plot(t, Eout/1000, 'C0', linewidth=3, linestyle='--' )
xlabel('t (ns)')
ylabel('Heat (keV)')
title('(b)')
tight_layout()
savefig('kappa.png')
show()
close()

deltaT = temp_ave[1] - temp_ave[-2]  # [K]
Q1 = (Ein[int(ndata/2) - 1] - Ein[-1])/(ndata/2)/dt/Ns
Q2 = (Eout[-1] - Eout[int(ndata/2) - 1])/(ndata/2)/dt/Ns
Q = mean([Q1, Q2])  # [eV/ps]
A = 24.6 * 3.4
thermo = load_thermo()
lx = thermo['Lx'][-1]
kappa = 1602 * (lx - 15 - 2 * 300) * 4 / 5 * Q / deltaT / A  # [W/m/K]
print(kappa)
with open('temp_ave.txt', 'w') as fl:
    for i in range(0, len(temp_ave)):
        fl.writelines(str(temp_ave[i]) + '\n')
with open('kappa.txt', 'w') as fl:
    fl.writelines(str(deltaT) + '\n')
    fl.writelines(str(Q) + '\n')
    fl.writelines(str(kappa) + '\n')

